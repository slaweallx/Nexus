<?php
/**
 * User English Language File for Nexus Theme
 *
 * @package Cotonti
 * @copyright (c) Cotonti Team
 * @license https://github.com/Cotonti/Cotonti/blob/master/License.txt
 */

defined('COT_CODE') or die('Wrong URL.');

/**
 * Put your theme-specific language strings here
 */

$L['Contact'] = 'Contact';
$L['Sitemap'] = 'Sitemap';
